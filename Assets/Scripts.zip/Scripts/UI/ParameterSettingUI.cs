using UnityEngine;
using UnityEngine.UI;

namespace PIDSimulator
{
    public class ParameterSettingUI : MonoBehaviour
    {
        [SerializeField] private InputField kpInput;
        [SerializeField] private InputField kiInput;
        [SerializeField] private InputField kdInput;
        [SerializeField] private InputField targetInput;
        [SerializeField] private InputField massInput;
        [SerializeField] private Button startButton;

        private void Start()
        {
            if (kpInput == null) kpInput = GameObject.Find("Kp Input")?.GetComponent<InputField>();
            if (kiInput == null) kiInput = GameObject.Find("Ki Input")?.GetComponent<InputField>();
            if (kdInput == null) kdInput = GameObject.Find("Kd Input")?.GetComponent<InputField>();
            if (targetInput == null) targetInput = GameObject.Find("Target Input")?.GetComponent<InputField>();
            if (massInput == null) massInput = GameObject.Find("Mass Input")?.GetComponent<InputField>();
            if (startButton == null) startButton = GameObject.Find("Start Simulation Button")?.GetComponent<Button>();

            if (startButton != null) startButton.onClick.AddListener(OnStartButtonClick);
        }

        public void OnStartButtonClick()
        {
            if (SceneController.Instance == null) return;

            try
            {
                float kp = float.Parse(kpInput.text);
                float ki = float.Parse(kiInput.text);
                float kd = float.Parse(kdInput.text);
                float target = float.Parse(targetInput.text);
                float mass = float.Parse(massInput.text);

                SceneController.Instance.SetSimulationParams(
                    SceneController.Instance.SelectedModelName,
                    kp, ki, kd, target, mass
                );

                SceneController.Instance.LoadSimulation(SceneController.Instance.SelectedModelName);
            }
            catch (System.Exception ex)
            {
                Debug.LogError($"[ParameterSettingUI] Error: {ex.Message}");
            }
        }
    }
}
