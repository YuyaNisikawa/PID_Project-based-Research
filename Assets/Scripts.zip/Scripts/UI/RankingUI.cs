using UnityEngine;
using UnityEngine.UI;

namespace PIDSimulator
{
    public class RankingUI : MonoBehaviour
    {
        [SerializeField] private Text rankingText;
        [SerializeField] private Button backButton;

        private void Start()
        {
            if (rankingText == null) rankingText = GameObject.Find("RankingText")?.GetComponent<Text>();
            if (backButton == null) backButton = GameObject.Find("Back Button")?.GetComponent<Button>();

            if (backButton != null) backButton.onClick.AddListener(OnBackToMenu);

            DisplayRanking();
        }

        private void DisplayRanking()
        {
            if (SceneController.Instance == null) return;

            string modelName = SceneController.Instance.SelectedModelName;
            if (string.IsNullOrEmpty(modelName)) modelName = "Inverted Pendulum";

            var entries = RankingManager.GetRankingEntries(modelName);
            if (rankingText != null)
            {
                rankingText.text = $"Ranking for {modelName}\n\n";
                for (int i = 0; i < entries.Count; i++)
                {
                    rankingText.text += $"{i + 1}. Score: {entries[i].Score:F0} ({entries[i].Date})\n";
                }
            }
        }

        public void OnBackToMenu()
        {
            if (SceneController.Instance != null) SceneController.Instance.LoadMainMenu();
        }
    }
}
