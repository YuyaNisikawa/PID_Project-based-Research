using UnityEngine;
using UnityEngine.UI;

namespace PIDSimulator
{
    public class SimulationUI : MonoBehaviour
    {
        [SerializeField] private Text statusText;
        [SerializeField] private Text timeText;
        [SerializeField] private Text modelNameText;
        [SerializeField] private Button stopButton;
        [SerializeField] private SimpleGraph graph;

        private void Start()
        {
            if (statusText == null) statusText = GameObject.Find("StatusText")?.GetComponent<Text>();
            if (timeText == null) timeText = GameObject.Find("TimeText")?.GetComponent<Text>();
            if (modelNameText == null) modelNameText = GameObject.Find("ModelNameText")?.GetComponent<Text>();
            if (stopButton == null) stopButton = GameObject.Find("StopButton")?.GetComponent<Button>();
            if (graph == null) graph = FindObjectOfType<SimpleGraph>();

            if (stopButton != null) stopButton.onClick.AddListener(OnStopButtonClick);
            
            if (SimulationManager.Instance != null)
            {
                SimulationManager.Instance.OnValueUpdated.AddListener(UpdateGraph);
                SimulationManager.Instance.OnSimulationStarted.AddListener(() => { if (graph != null) graph.ClearGraph(); });
            }
        }

        private void Update()
        {
            if (SimulationManager.Instance == null) return;

            var manager = SimulationManager.Instance;
            if (statusText != null) statusText.text = $"Status: {manager.CurrentState}";
            if (timeText != null) timeText.text = $"Time: {manager.ElapsedTime:F2}s";
            
            if (modelNameText != null && manager.PhysicsModel != null)
                modelNameText.text = "Model: " + manager.PhysicsModel.GetModelName();
            else if (modelNameText != null && SceneController.Instance != null)
                modelNameText.text = "Model: " + SceneController.Instance.SelectedModelName;
        }

        private void UpdateGraph(float current, float target)
        {
            if (graph != null) graph.UpdateGraph(current, target);
        }

        public void OnStopButtonClick()
        {
            if (SimulationManager.Instance != null)
                SimulationManager.Instance.StopSimulation();
        }
    }
}
