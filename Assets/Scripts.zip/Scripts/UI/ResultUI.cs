using UnityEngine;
using UnityEngine.UI;

namespace PIDSimulator
{
    public class ResultUI : MonoBehaviour
    {
        [SerializeField] private Text scoreText;
        [SerializeField] private Button retryButton;
        [SerializeField] private Button menuButton;

        private void Start()
        {
            if (scoreText == null) scoreText = GameObject.Find("ScoreText")?.GetComponent<Text>();
            if (menuButton == null) menuButton = GameObject.Find("Main Menu Button")?.GetComponent<Button>();
            if (retryButton == null) retryButton = GameObject.Find("Retry Button")?.GetComponent<Button>();

            if (retryButton != null) retryButton.onClick.AddListener(OnRetryButtonClick);
            if (menuButton != null) menuButton.onClick.AddListener(OnMenuButtonClick);

            DisplayResult();
        }

        private void DisplayResult()
        {
            if (SceneController.Instance == null || SceneController.Instance.LastResult == null) return;
            var result = SceneController.Instance.LastResult;
            if (scoreText != null) scoreText.text = $"Score: {result.Score:F0}";
        }

        public void OnRetryButtonClick()
        {
            if (SceneController.Instance != null) SceneController.Instance.LoadParameterSetting();
        }

        public void OnMenuButtonClick()
        {
            if (SceneController.Instance != null) SceneController.Instance.LoadMainMenu();
        }
    }
}
