using UnityEngine;
using UnityEngine.UI;

namespace PIDSimulator
{
    public class MainMenuUI : MonoBehaviour
    {
        private void Start()
        {
            Button[] buttons = FindObjectsOfType<Button>();
            foreach (var btn in buttons)
            {
                string btnName = btn.gameObject.name;
                if (btnName == "Inverted Pendulum Button") btn.onClick.AddListener(() => OnModelButtonClick("Inverted Pendulum"));
                else if (btnName == "Helicopter Button") btn.onClick.AddListener(() => OnModelButtonClick("Helicopter"));
                else if (btnName == "Crane Button") btn.onClick.AddListener(() => OnModelButtonClick("Crane"));
                else if (btnName == "Ranking Button") btn.onClick.AddListener(OnRankingButtonClick);
            }
        }

        private void OnModelButtonClick(string modelName)
        {
            if (SceneController.Instance != null)
            {
                SceneController.Instance.SelectModel(modelName);
                SceneController.Instance.LoadParameterSetting();
            }
        }

        private void OnRankingButtonClick()
        {
            if (SceneController.Instance != null) SceneController.Instance.LoadRanking();
        }
    }
}
