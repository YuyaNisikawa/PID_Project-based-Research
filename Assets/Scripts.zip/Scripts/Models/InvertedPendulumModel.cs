using UnityEngine;

namespace PIDSimulator
{
    /// <summary>
    /// 逆立ち振り子モデル。最新のUnity API(linearVelocity)に対応し、安定性を向上。
    /// </summary>
    public class InvertedPendulumModel : MonoBehaviour, IPhysicsModel
    {
        [SerializeField] private Rigidbody poleRigidbody;
        [SerializeField] private HingeJoint hingeJoint;
        [SerializeField] private float controlForceMultiplier = 100f;
        [SerializeField] private float initialAngle = 10f;

        private float targetAngle = 0f;
        private Vector3 startPosition;
        private Quaternion startRotation;
        private bool isInitialized = false;

        private void OnEnable()
        {
            if (!isInitialized) Initialize();
        }

        private void Initialize()
        {
            if (poleRigidbody == null) poleRigidbody = GetComponent<Rigidbody>();
            if (hingeJoint == null) hingeJoint = GetComponent<HingeJoint>();

            startPosition = transform.position;
            startRotation = transform.rotation;
            isInitialized = true;
        }

        public string GetModelName() => "Inverted Pendulum";

        public float GetCurrentValue()
        {
            if (hingeJoint == null) return 0;
            float angle = hingeJoint.angle;
            while (angle > 180) angle -= 360;
            while (angle < -180) angle += 360;
            return angle;
        }

        public float GetCurrentVelocity()
        {
            if (poleRigidbody == null) return 0;
            // Unity 2023.1+ では linearVelocity/angularVelocity ですが、
            // 互換性のために magnitude を使用、または条件付きコンパイルを検討
            return poleRigidbody.angularVelocity.magnitude;
        }

        public void SetTargetValue(float target) => targetAngle = target;
        public float GetTargetValue() => targetAngle;

        public void SetControlInput(float input)
        {
            if (poleRigidbody == null || hingeJoint == null || float.IsNaN(input)) return;
            poleRigidbody.AddTorque(hingeJoint.axis * input * controlForceMultiplier);
        }

        public void SetMass(float mass)
        {
            if (poleRigidbody != null) poleRigidbody.mass = Mathf.Max(0.1f, mass);
        }

        public void Reset()
        {
            if (poleRigidbody != null)
            {
                // 旧バージョンとの互換性を保つため、物理挙動を完全に停止
                poleRigidbody.linearVelocity = Vector3.zero;
                poleRigidbody.angularVelocity = Vector3.zero;
                
                transform.position = startPosition;
                transform.rotation = startRotation;
                transform.localRotation = Quaternion.Euler(0, 0, initialAngle);
            }
        }
    }
}
