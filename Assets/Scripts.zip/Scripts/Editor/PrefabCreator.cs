using UnityEngine;
using UnityEditor;

namespace PIDSimulator
{
    public class PrefabCreator : MonoBehaviour
    {
        [MenuItem("PID Simulator/Create Prefabs/Create InvertedPendulum Prefab")]
        public static void CreateInvertedPendulumPrefab()
        {
            GameObject root = new GameObject("InvertedPendulum");
            root.AddComponent<InvertedPendulumModel>();
            root.AddComponent<Rigidbody>();

            GameObject baseObj = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            baseObj.name = "Base";
            baseObj.transform.SetParent(root.transform);
            baseObj.transform.localPosition = Vector3.zero;
            baseObj.transform.localScale = new Vector3(0.5f, 0.1f, 0.5f);
            Rigidbody baseRb = baseObj.GetComponent<Rigidbody>();
            baseRb.isKinematic = true;
            DestroyImmediate(baseObj.GetComponent<Collider>());
            baseObj.AddComponent<CapsuleCollider>();

            GameObject poleObj = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            poleObj.name = "Pole";
            poleObj.transform.SetParent(root.transform);
            poleObj.transform.localPosition = new Vector3(0, 1f, 0);
            poleObj.transform.localScale = new Vector3(0.1f, 1f, 0.1f);
            Rigidbody poleRb = poleObj.GetComponent<Rigidbody>();
            poleRb.isKinematic = false;
            poleRb.mass = 1f;

            ConfigurableJoint joint = root.AddComponent<ConfigurableJoint>();
            joint.connectedBody = baseRb;
            joint.xMotion = ConfigurableJointMotion.Locked;
            joint.yMotion = ConfigurableJointMotion.Locked;
            joint.zMotion = ConfigurableJointMotion.Limited;
            joint.angularXMotion = ConfigurableJointMotion.Limited;
            joint.angularYMotion = ConfigurableJointMotion.Locked;
            joint.angularZMotion = ConfigurableJointMotion.Locked;

            string prefabPath = "Assets/Resources/Prefabs/Models/InvertedPendulum.prefab";
            CreatePrefabDirectory(prefabPath);
            PrefabUtility.SaveAsPrefabAsset(root, prefabPath);
            DestroyImmediate(root);

            Debug.Log("InvertedPendulum プレハブを作成しました: " + prefabPath);
        }

        [MenuItem("PID Simulator/Create Prefabs/Create Helicopter Prefab")]
        public static void CreateHelicopterPrefab()
        {
            GameObject root = new GameObject("Helicopter");
            root.AddComponent<HelicopterModel>();
            Rigidbody rootRb = root.AddComponent<Rigidbody>();
            rootRb.isKinematic = false;

            GameObject bodyObj = GameObject.CreatePrimitive(PrimitiveType.Cube);
            bodyObj.name = "Body";
            bodyObj.transform.SetParent(root.transform);
            bodyObj.transform.localPosition = Vector3.zero;
            bodyObj.transform.localScale = new Vector3(0.5f, 0.3f, 0.5f);
            Rigidbody bodyRb = bodyObj.GetComponent<Rigidbody>();
            bodyRb.isKinematic = false;
            bodyRb.mass = 2f;

            GameObject propellerObj = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            propellerObj.name = "Propeller";
            propellerObj.transform.SetParent(root.transform);
            propellerObj.transform.localPosition = new Vector3(0, 0.5f, 0);
            propellerObj.transform.localScale = new Vector3(1f, 0.05f, 1f);
            Rigidbody propellerRb = propellerObj.GetComponent<Rigidbody>();
            propellerRb.isKinematic = true;

            string prefabPath = "Assets/Resources/Prefabs/Models/Helicopter.prefab";
            CreatePrefabDirectory(prefabPath);
            PrefabUtility.SaveAsPrefabAsset(root, prefabPath);
            DestroyImmediate(root);

            Debug.Log("Helicopter プレハブを作成しました: " + prefabPath);
        }

        [MenuItem("PID Simulator/Create Prefabs/Create Crane Prefab")]
        public static void CreateCranePrefab()
        {
            GameObject root = new GameObject("Crane");
            root.AddComponent<CraneModel>();
            Rigidbody rootRb = root.AddComponent<Rigidbody>();
            rootRb.isKinematic = false;

            GameObject armObj = GameObject.CreatePrimitive(PrimitiveType.Cube);
            armObj.name = "Arm";
            armObj.transform.SetParent(root.transform);
            armObj.transform.localPosition = new Vector3(0, 0.5f, 0);
            armObj.transform.localScale = new Vector3(0.2f, 0.2f, 2f);
            Rigidbody armRb = armObj.GetComponent<Rigidbody>();
            armRb.isKinematic = true;

            GameObject hookObj = GameObject.CreatePrimitive(PrimitiveType.Cube);
            hookObj.name = "Hook";
            hookObj.transform.SetParent(root.transform);
            hookObj.transform.localPosition = new Vector3(0, -0.5f, 0);
            hookObj.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
            Rigidbody hookRb = hookObj.GetComponent<Rigidbody>();
            hookRb.isKinematic = false;
            hookRb.mass = 1f;

            GameObject cableObj = new GameObject("Cable");
            cableObj.transform.SetParent(root.transform);
            cableObj.transform.localPosition = Vector3.zero;
            LineRenderer lineRenderer = cableObj.AddComponent<LineRenderer>();
            lineRenderer.positionCount = 2;
            lineRenderer.SetPosition(0, armObj.transform.position);
            lineRenderer.SetPosition(1, hookObj.transform.position);
            lineRenderer.startWidth = 0.05f;
            lineRenderer.endWidth = 0.05f;

            string prefabPath = "Assets/Resources/Prefabs/Models/Crane.prefab";
            CreatePrefabDirectory(prefabPath);
            PrefabUtility.SaveAsPrefabAsset(root, prefabPath);
            DestroyImmediate(root);

            Debug.Log("Crane プレハブを作成しました: " + prefabPath);
        }

        [MenuItem("PID Simulator/Create Prefabs/Create SimulationManager Prefab")]
        public static void CreateSimulationManagerPrefab()
        {
            GameObject root = new GameObject("SimulationManager");
            root.AddComponent<SimulationManager>();
            root.AddComponent<PIDController>();

            // Note: DataRecorder is no longer a MonoBehaviour, so it's not added as a component.
            // SimulationManager initializes it in Awake().

            string prefabPath = "Assets/Resources/Prefabs/Managers/SimulationManager.prefab";
            CreatePrefabDirectory(prefabPath);
            PrefabUtility.SaveAsPrefabAsset(root, prefabPath);
            DestroyImmediate(root);

            Debug.Log("SimulationManager プレハブを作成しました: " + prefabPath);
        }

        [MenuItem("PID Simulator/Create Prefabs/Create ModelManager Prefab")]
        public static void CreateModelManagerPrefab()
        {
            GameObject root = new GameObject("ModelManager");
            root.AddComponent<ModelManager>();

            string prefabPath = "Assets/Resources/Prefabs/Managers/ModelManager.prefab";
            CreatePrefabDirectory(prefabPath);
            PrefabUtility.SaveAsPrefabAsset(root, prefabPath);
            DestroyImmediate(root);

            Debug.Log("ModelManager プレハブを作成しました: " + prefabPath);
        }

        [MenuItem("PID Simulator/Create Prefabs/Create All Prefabs")]
        public static void CreateAllPrefabs()
        {
            CreateInvertedPendulumPrefab();
            CreateHelicopterPrefab();
            CreateCranePrefab();
            CreateSimulationManagerPrefab();
            CreateModelManagerPrefab();
            AssetDatabase.Refresh();
        }

        private static void CreatePrefabDirectory(string prefabPath)
        {
            string directory = System.IO.Path.GetDirectoryName(prefabPath);
            if (!System.IO.Directory.Exists(directory))
            {
                System.IO.Directory.CreateDirectory(directory);
            }
        }
    }
}
