using UnityEngine;
using UnityEngine.UI;
using UnityEditor;
using UnityEditor.SceneManagement;
using System;
using System.IO;
using System.Reflection;

namespace PIDSimulator
{
    public class PIDSimulatorSetup : EditorWindow
    {
        private const string BASE_PATH = "Assets/Scripts";
        private const string PREFABS_PATH = "Assets/Prefabs";
        private const string SCENES_PATH = "Assets/Scenes";
        private const string CONFIGS_PATH = "Assets/Configs";

        [MenuItem("PID Simulator/Setup/1. Create Folders")]
        public static void CreateFolders()
        {
            if (!AssetDatabase.IsValidFolder(PREFABS_PATH)) AssetDatabase.CreateFolder("Assets", "Prefabs");
            if (!AssetDatabase.IsValidFolder(SCENES_PATH)) AssetDatabase.CreateFolder("Assets", "Scenes");
            if (!AssetDatabase.IsValidFolder(CONFIGS_PATH)) AssetDatabase.CreateFolder("Assets", "Configs");
            Debug.Log("✅ Folder structure created.");
        }

        [MenuItem("PID Simulator/Setup/2. Create Model Prefabs and Configs")]
        public static void CreateModelPrefabsAndConfigs()
        {
            PrefabCreator.CreateInvertedPendulumPrefab();
            PrefabCreator.CreateHelicopterPrefab();
            PrefabCreator.CreateCranePrefab();
            
            CreateModelConfig("Inverted Pendulum", 1.0f, 10.0f);
            CreateModelConfig("Helicopter", 1.0f, 5.0f);
            CreateModelConfig("Crane", 1.0f, 10.0f);

            AssetDatabase.Refresh();
            Debug.Log("✅ Model prefabs and configs created.");
        }

        private static void CreateModelConfig(string modelName, float mass, float target)
        {
            string path = $"{CONFIGS_PATH}/ModelConfig_{modelName.Replace(" ", "_")}.asset";
            ModelConfig config = AssetDatabase.LoadAssetAtPath<ModelConfig>(path);
            if (config == null)
            {
                config = ScriptableObject.CreateInstance<ModelConfig>();
                AssetDatabase.CreateAsset(config, path);
            }
            config.modelName = modelName;
            config.defaultMass = mass;
            config.defaultTargetValue = target;
            EditorUtility.SetDirty(config);
        }

        [MenuItem("PID Simulator/Setup/3. Create Manager Prefabs")]
        public static void CreateManagerPrefabs()
        {
            CreateSimulationManagerPrefab();
            CreateSceneControllerPrefab();
            CreateRankingManagerPrefab();
            Debug.Log("✅ Manager prefabs created.");
        }

        private static void CreateSimulationManagerPrefab()
        {
            string path = $"{PREFABS_PATH}/SimulationManager.prefab";
            GameObject go = new GameObject("SimulationManager");
            go.AddComponent<SimulationManager>();
            go.AddComponent<PIDController>();
            // 修正: SaveAsPrefabAndConnect の引数を修正
            PrefabUtility.SaveAsPrefabAndConnect(go, path, InteractionMode.AutomatedAction);
            UnityEngine.Object.DestroyImmediate(go);
        }

        private static void CreateSceneControllerPrefab()
        {
            string path = $"{PREFABS_PATH}/SceneController.prefab";
            GameObject go = new GameObject("SceneController");
            go.AddComponent<SceneController>();
            // 修正: SaveAsPrefabAndConnect の引数を修正
            PrefabUtility.SaveAsPrefabAndConnect(go, path, InteractionMode.AutomatedAction);
            UnityEngine.Object.DestroyImmediate(go);
        }

        private static void CreateRankingManagerPrefab()
        {
            string path = $"{PREFABS_PATH}/RankingManager.prefab";
            GameObject go = new GameObject("RankingManager");
            // RankingManagerがMonoBehaviourになったのでAddComponent可能
            go.AddComponent<RankingManager>();
            // 修正: SaveAsPrefabAndConnect の引数を修正
            PrefabUtility.SaveAsPrefabAndConnect(go, path, InteractionMode.AutomatedAction);
            UnityEngine.Object.DestroyImmediate(go);
        }

        [MenuItem("PID Simulator/Setup/4. Setup All Scenes")]
        public static void SetupAllScenes()
        {
            SetupMainMenuScene();
            SetupParameterSettingScene();
            SetupSimulationScene();
            SetupResultScene();
            SetupRankingScene();
            Debug.Log("✅ All scenes setup completed.");
        }

        [MenuItem("PID Simulator/Setup/Scenes/Main Menu")]
        public static void SetupMainMenuScene()
        {
            var scene = PrepareScene($"{SCENES_PATH}/MainMenu.unity");
            var canvas = CreateCanvas();
            CreateText(canvas, "PID Simulator", new Vector2(0, 200), 48);
            
            string[] models = { "Inverted Pendulum", "Helicopter", "Crane" };
            for (int i = 0; i < models.Length; i++)
            {
                CreateButton(canvas, models[i], new Vector2(0, 50 - i * 60));
            }
            
            var mainMenuUI = new GameObject("MainMenuUI").AddComponent<MainMenuUI>();
            InstantiatePrefab("SceneController");
            
            EditorSceneManager.SaveScene(scene);
        }

        [MenuItem("PID Simulator/Setup/Scenes/Parameter Setting")]
        public static void SetupParameterSettingScene()
        {
            var scene = PrepareScene($"{SCENES_PATH}/ParameterSetting.unity");
            var canvas = CreateCanvas();
            CreateText(canvas, "PID Parameters", new Vector2(0, 200), 36);
            
            CreateInputField(canvas, "Kp", new Vector2(0, 100), "1.0");
            CreateInputField(canvas, "Ki", new Vector2(0, 40), "0.1");
            CreateInputField(canvas, "Kd", new Vector2(0, -20), "0.05");
            CreateInputField(canvas, "Target", new Vector2(0, -80), "10.0");
            CreateInputField(canvas, "Mass", new Vector2(0, -140), "1.0");
            
            CreateButton(canvas, "Start Simulation", new Vector2(0, -220));
            
            new GameObject("ParameterSettingUI").AddComponent<ParameterSettingUI>();
            InstantiatePrefab("SceneController");
            
            EditorSceneManager.SaveScene(scene);
        }

        [MenuItem("PID Simulator/Setup/Scenes/Simulation")]
        public static void SetupSimulationScene()
        {
            var scene = PrepareScene($"{SCENES_PATH}/Simulation.unity");
            var canvas = CreateCanvas();
            
            CreateText(canvas, "Status: Idle", new Vector2(-300, 200), 24, "StatusText");
            CreateText(canvas, "Time: 0.00s", new Vector2(-300, 160), 24, "TimeText");
            CreateText(canvas, "Model: None", new Vector2(-300, 120), 24, "ModelNameText");
            
            CreateButton(canvas, "Stop", new Vector2(350, -200), "StopButton");
            
            // グラフの作成
            var graphObj = new GameObject("SimpleGraph", typeof(RectTransform), typeof(RawImage), typeof(SimpleGraph));
            graphObj.transform.SetParent(canvas.transform, false);
            var rt = graphObj.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(1, 1);
            rt.anchorMax = new Vector2(1, 1);
            rt.pivot = new Vector2(1, 1);
            rt.sizeDelta = new Vector2(400, 200);
            rt.anchoredPosition = new Vector2(-20, -20);
            graphObj.GetComponent<RawImage>().color = new Color(0, 0, 0, 0.5f);
            
            new GameObject("SimulationUI").AddComponent<SimulationUI>();
            InstantiatePrefab("SimulationManager");
            InstantiatePrefab("SceneController");
            InstantiatePrefab("RankingManager");
            
            // ModelManagerも配置
            var modelManager = new GameObject("ModelManager").AddComponent<ModelManager>();
            
            EditorSceneManager.SaveScene(scene);
        }

        [MenuItem("PID Simulator/Setup/Scenes/Result")]
        public static void SetupResultScene()
        {
            var scene = PrepareScene($"{SCENES_PATH}/Result.unity");
            var canvas = CreateCanvas();
            CreateText(canvas, "Simulation Result", new Vector2(0, 200), 36);
            
            CreateText(canvas, "Score: 0", new Vector2(0, 100), 24, "ScoreText");
            CreateText(canvas, "Time: 0s", new Vector2(0, 60), 24, "TimeText");
            CreateText(canvas, "Overshoot: 0%", new Vector2(0, 20), 24, "OvershootText");
            
            // 結果用グラフ
            var graphObj = new GameObject("ResultGraph", typeof(RectTransform), typeof(RawImage), typeof(SimpleGraph));
            graphObj.transform.SetParent(canvas.transform, false);
            var rt = graphObj.GetComponent<RectTransform>();
            rt.sizeDelta = new Vector2(600, 300);
            rt.anchoredPosition = new Vector2(0, -100);
            
            CreateButton(canvas, "Back to Menu", new Vector2(-100, -250));
            CreateButton(canvas, "View Ranking", new Vector2(100, -250));
            
            new GameObject("ResultUI").AddComponent<ResultUI>();
            InstantiatePrefab("SceneController");
            
            EditorSceneManager.SaveScene(scene);
        }

        [MenuItem("PID Simulator/Setup/Scenes/Ranking")]
        public static void SetupRankingScene()
        {
            var scene = PrepareScene($"{SCENES_PATH}/Ranking.unity");
            var canvas = CreateCanvas();
            CreateText(canvas, "High Scores", new Vector2(0, 200), 36);
            
            var content = new GameObject("RankingContent", typeof(RectTransform));
            content.transform.SetParent(canvas.transform, false);
            
            CreateButton(canvas, "Back to Menu", new Vector2(0, -220));
            
            new GameObject("RankingUI").AddComponent<RankingUI>();
            InstantiatePrefab("SceneController");
            InstantiatePrefab("RankingManager");
            
            EditorSceneManager.SaveScene(scene);
        }

        [MenuItem("PID Simulator/Setup/5. Complete Setup (All in One)")]
        public static void CompleteSetup()
        {
            CreateFolders();
            CreateModelPrefabsAndConfigs();
            CreateManagerPrefabs();
            SetupAllScenes();
            Debug.Log("✨ PID Simulator Setup Complete!");
        }

        // --- Helper Methods ---

        private static UnityEngine.SceneManagement.Scene PrepareScene(string path)
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
            // デフォルトのカメラ以外を削除
            foreach (var go in scene.GetRootGameObjects())
            {
                if (go.name != "Main Camera" && go.name != "Directional Light")
                    UnityEngine.Object.DestroyImmediate(go);
            }
            return scene;
        }

        private static Canvas CreateCanvas()
        {
            var root = new GameObject("Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            var canvas = root.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            
            var es = new GameObject("EventSystem", typeof(UnityEngine.EventSystems.EventSystem));
            // 新入力システム対応
            Type inputModuleType = Type.GetType("UnityEngine.InputSystem.UI.InputSystemUIInputModule, Unity.InputSystem");
            if (inputModuleType != null)
                es.AddComponent(inputModuleType);
            else
                es.AddComponent<UnityEngine.EventSystems.StandaloneInputModule>();
                
            return canvas;
        }

        private static Text CreateText(Canvas canvas, string content, Vector2 pos, int fontSize, string name = "Text")
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Text));
            go.transform.SetParent(canvas.transform, false);
            var text = go.GetComponent<Text>();
            text.text = content;
            text.fontSize = fontSize;
            text.alignment = TextAnchor.MiddleCenter;
            text.color = Color.white;
            text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            
            var rt = go.GetComponent<RectTransform>();
            rt.sizeDelta = new Vector2(400, fontSize * 1.5f);
            rt.anchoredPosition = pos;
            return text;
        }

        private static Button CreateButton(Canvas canvas, string label, Vector2 pos, string name = "Button")
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
            go.transform.SetParent(canvas.transform, false);
            
            var rt = go.GetComponent<RectTransform>();
            rt.sizeDelta = new Vector2(160, 40);
            rt.anchoredPosition = pos;
            
            var img = go.GetComponent<Image>();
            img.color = new Color(0.2f, 0.2f, 0.2f);
            
            var textGo = new GameObject("Text", typeof(RectTransform), typeof(Text));
            textGo.transform.SetParent(go.transform, false);
            var text = textGo.GetComponent<Text>();
            text.text = label;
            text.fontSize = 18;
            text.alignment = TextAnchor.MiddleCenter;
            text.color = Color.white;
            text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            
            textGo.GetComponent<RectTransform>().sizeDelta = rt.sizeDelta;
            
            return go.GetComponent<Button>();
        }

        private static InputField CreateInputField(Canvas canvas, string label, Vector2 pos, string defaultVal)
        {
            var root = new GameObject(label + "Field", typeof(RectTransform), typeof(Image), typeof(InputField));
            root.transform.SetParent(canvas.transform, false);
            var rt = root.GetComponent<RectTransform>();
            rt.sizeDelta = new Vector2(200, 30);
            rt.anchoredPosition = pos;
            
            var labelGo = new GameObject("Label", typeof(RectTransform), typeof(Text));
            labelGo.transform.SetParent(root.transform, false);
            var lText = labelGo.GetComponent<Text>();
            lText.text = label + ":";
            lText.alignment = TextAnchor.MiddleRight;
            lText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            var lRt = labelGo.GetComponent<RectTransform>();
            lRt.sizeDelta = new Vector2(100, 30);
            lRt.anchoredPosition = new Vector2(-160, 0);
            
            var textGo = new GameObject("Text", typeof(RectTransform), typeof(Text));
            textGo.transform.SetParent(root.transform, false);
            var tText = textGo.GetComponent<Text>();
            tText.supportRichText = false;
            tText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            tText.color = Color.black;
            var tRt = textGo.GetComponent<RectTransform>();
            tRt.anchorMin = Vector2.zero; tRt.anchorMax = Vector2.one;
            tRt.sizeDelta = Vector2.zero;
            
            var input = root.GetComponent<InputField>();
            input.textComponent = tText;
            input.text = defaultVal;
            
            return input;
        }

        private static void InstantiatePrefab(string name)
        {
            string path = $"{PREFABS_PATH}/{name}.prefab";
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
            if (prefab != null)
                PrefabUtility.InstantiatePrefab(prefab);
        }
    }
}
